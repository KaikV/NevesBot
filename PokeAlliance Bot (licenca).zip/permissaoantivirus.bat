@echo off
REM ===========================================================================
REM  KRYON - Liberar o bot no antivirus (Windows Defender)
REM ---------------------------------------------------------------------------
REM  PARA QUE SERVE: o launcher e' um programa unico que, ao abrir, extrai os
REM  arquivos dele numa pasta temporaria do Windows. Alguns antivirus apagam
REM  essa pasta com o programa RODANDO. Quando isso acontece o bot AINDA abre -
REM  ele tem plano B pra tudo -, mas a abertura fica mais lenta e aparecem
REM  avisos amarelos no log.
REM
REM  Este arquivo NAO desliga o antivirus. Ele so' diz ao Windows Defender
REM  "confie neste programa", que e' o minimo necessario - desligar a protecao
REM  inteira pra resolver isso seria trocar um incomodo por um risco de verdade.
REM
REM  Precisa de permissao de administrador (o Windows vai perguntar uma vez).
REM ===========================================================================
title KRYON - Liberar o bot no antivirus

REM --- ja' estamos como administrador? Se nao, pede e roda de novo. ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  Preciso de permissao de administrador - vou pedir agora.
    echo  ^(o Windows so' deixa mexer no antivirus com ela^)
    echo.
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
    if errorlevel 1 (
        echo  Nao consegui pedir a permissao.
        echo  Clique com o botao direito neste arquivo e escolha
        echo  "Executar como administrador".
        echo.
        pause
    )
    exit /b
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Continue';" ^
  "Write-Host '';" ^
  "Write-Host '  ==========================================================';" ^
  "Write-Host '   KRYON BOTS - liberar o bot no antivirus';" ^
  "Write-Host '  ==========================================================';" ^
  "Write-Host '';" ^
  "$st = Get-MpComputerStatus -ErrorAction SilentlyContinue;" ^
  "if (-not $st) {" ^
  "  Write-Host '  O Windows Defender nao respondeu nesta maquina.' -ForegroundColor Yellow;" ^
  "  Write-Host '  Se voce usa OUTRO antivirus (Avast, AVG, Kaspersky, McAfee...),';" ^
  "  Write-Host '  abra ele e adicione as EXCECOES abaixo na mao:';" ^
  "  Write-Host '';" ^
  "  Write-Host '     - a pasta onde fica o PokeAlliance Bot (licenca).exe';" ^
  "  Write-Host '     - a pasta do jogo PokeAlliance';" ^
  "  Write-Host '';" ^
  "  Read-Host '  Enter para fechar'; exit 1 }" ^
  "$add = @();" ^
  "$meu = Split-Path -Parent '%~f0';" ^
  "if (Get-ChildItem -LiteralPath $meu -Filter 'PokeAlliance Bot*.exe' -ErrorAction SilentlyContinue) {" ^
  "  $add += $meu }" ^
  "else {" ^
  "  Write-Host '  Obs: o exe do bot nao esta nesta pasta, entao NAO vou liberar a' -ForegroundColor DarkGray;" ^
  "  Write-Host '  pasta inteira (liberar uma pasta como Downloads seria perigoso).' -ForegroundColor DarkGray;" ^
  "  Write-Host '  Os programas abaixo ja resolvem o problema de qualquer jeito.' -ForegroundColor DarkGray;" ^
  "  Write-Host '' }" ^
  "foreach ($c in @(\"$env:LOCALAPPDATA\PokeAlliance Games\PokeAlliance\", \"$env:APPDATA\PokeAlliance\", \"$env:APPDATA\KryonPA\")) {" ^
  "  if (Test-Path $c) { $add += $c } }" ^
  "$procs = @('PokeAlliance Bot (licenca).exe','PokeAlliance Bot (direto).exe','PokeAlliance_dx.exe','PokeAlliance_gl.exe');" ^
  "$jaP = @(); $jaX = @();" ^
  "$pref = Get-MpPreference -ErrorAction SilentlyContinue;" ^
  "if ($pref) { $jaP = @($pref.ExclusionPath); $jaX = @($pref.ExclusionProcess) }" ^
  "$n = 0;" ^
  "Write-Host '  Pastas liberadas:';" ^
  "foreach ($p in ($add | Select-Object -Unique)) {" ^
  "  if ($jaP -contains $p) { Write-Host ('     ja estava: ' + $p) -ForegroundColor DarkGray }" ^
  "  else { Add-MpPreference -ExclusionPath $p -ErrorAction SilentlyContinue;" ^
  "         if ($?) { $n++; Write-Host ('     + ' + $p) -ForegroundColor Green }" ^
  "         else { Write-Host ('     ! nao consegui: ' + $p) -ForegroundColor Yellow } } }" ^
  "Write-Host '';" ^
  "Write-Host '  Programas liberados:';" ^
  "foreach ($x in $procs) {" ^
  "  if ($jaX -contains $x) { Write-Host ('     ja estava: ' + $x) -ForegroundColor DarkGray }" ^
  "  else { Add-MpPreference -ExclusionProcess $x -ErrorAction SilentlyContinue;" ^
  "         if ($?) { $n++; Write-Host ('     + ' + $x) -ForegroundColor Green }" ^
  "         else { Write-Host ('     ! nao consegui: ' + $x) -ForegroundColor Yellow } } }" ^
  "Write-Host '';" ^
  "$dep = Get-MpPreference -ErrorAction SilentlyContinue;" ^
  "$okP = @($dep.ExclusionPath); $okX = @($dep.ExclusionProcess);" ^
  "$falta = @();" ^
  "foreach ($p in ($add | Select-Object -Unique)) { if ($okP -notcontains $p) { $falta += $p } }" ^
  "foreach ($x in $procs) { if ($okX -notcontains $x) { $falta += $x } }" ^
  "if ($falta.Count -eq 0) {" ^
  "  Write-Host '  PRONTO - tudo liberado. Pode abrir o launcher normalmente.' -ForegroundColor Green;" ^
  "  if ($n -eq 0) { Write-Host '  (ja estava tudo liberado antes; nada mudou)' -ForegroundColor DarkGray } }" ^
  "else {" ^
  "  Write-Host '  ATENCAO: estes NAO entraram:' -ForegroundColor Yellow;" ^
  "  $falta | ForEach-Object { Write-Host ('     - ' + $_) };" ^
  "  Write-Host '';" ^
  "  Write-Host '  Quase sempre e porque a empresa/escola bloqueia mexer no antivirus,';" ^
  "  Write-Host '  ou porque outro antivirus esta no comando. O bot funciona assim';" ^
  "  Write-Host '  mesmo - so abre um pouco mais devagar.' }" ^
  "Write-Host '';" ^
  "if (-not $st.RealTimeProtectionEnabled) {" ^
  "  Write-Host '  Obs: a protecao em tempo real do Defender esta DESLIGADA nesta' -ForegroundColor Yellow;" ^
  "  Write-Host '  maquina. Voce nao precisa desligar nada pro bot funcionar -' -ForegroundColor Yellow;" ^
  "  Write-Host '  com as excecoes acima da pra deixar ela LIGADA.' -ForegroundColor Yellow;" ^
  "  Write-Host '' }" ^
  "Read-Host '  Enter para fechar'"

exit /b
